#!/usr/bin/env python3
"""Round 40 (idempotent). Usage: python3 tools/round40_fixes.py build.log src/port/java
 A. Screen.hasControlDown/hasShiftDown/hasAltDown() -> Minecraft.getInstance().hasXDown(). Static Screen methods are gone
    (javac: cannot find symbol); a real MC 1.21.9+ mod migration (BetterControls) uses Minecraft.getInstance().hasXDown().
 B. pose.mulPose(<Quaternionf>) -> pose.mulPose(new org.joml.Matrix4f().rotation(<q>)): javac lists only
    PoseStack.mulPose(Matrix4fc) and mulPose(Transformation); JOML's Matrix4f.rotation(Quaternionfc) builds the same rotation.
 C. GUI subclass constructors get a leading `IGuiParent parent` (CreativeCore 26.x controls take the parent first; verified from
    GuiControl/GuiParent sources + javac constructor lists). The ctor's super(...)/this(...) forwards it and every `new X(...)`
    gets `<enclosing add() receiver>` or `this`. Sites where `this` is not a GUI parent are listed, not guessed."""
import re, sys, pathlib, collections
log = open(sys.argv[1], encoding="utf-8", errors="replace").read().split("\n"); root = pathlib.Path(sys.argv[2])
files = {f: f.read_text(encoding="utf-8") for f in root.rglob("*.java")}
changed = set(); report = collections.Counter(); pending = []
def imp(t, cls):
    if re.search(r"^import\s+" + re.escape(cls) + ";", t, re.M): return t
    m = re.search(r"^import ", t, re.M)
    return (t[:m.start()] + "import " + cls + ";\n" + t[m.start():]) if m else re.sub(r"(^package [^;]+;\n)", r"\1\nimport " + cls + ";\n", t, count=1, flags=re.M)
# ---- A
A = re.compile(r"(?<![\w.])Screen\.(hasControlDown|hasShiftDown|hasAltDown)\(\)")
for f, t in files.items():
    n = len(A.findall(t))
    if n:
        t2 = imp(A.sub(lambda m: "Minecraft.getInstance()." + m.group(1) + "()", t), "net.minecraft.client.Minecraft")
        files[f] = t2; changed.add(f); report["hasXDown"] += n
# ---- B
rxe = re.compile(r"^.*?src/port/java/(.*\.java):(\d+): error: no suitable method found for mulPose\(")
flag = collections.defaultdict(set)
for l in log:
    m = rxe.match(l)
    if m: flag[m.group(1)].add(int(m.group(2)))
for rel, lns in flag.items():
    f = root / rel
    if f not in files: continue
    lines = files[f].split("\n")
    for n in sorted(lns):
        s = lines[n - 1]; k = s.find(".mulPose(")
        if k < 0 or "Matrix4f().rotation(" in s: continue
        a = k + len(".mulPose("); depth = 1; j = a
        while j < len(s) and depth:
            depth += (s[j] == "(") - (s[j] == ")"); j += 1
        if depth: continue
        lines[n - 1] = s[:a] + "new org.joml.Matrix4f().rotation(" + s[a:j - 1] + ")" + s[j - 1:]; report["mulPose"] += 1; changed.add(f)
    files[f] = "\n".join(lines)
# ---- C
ELIGIBLE = ["GuiActionDisplay", "GuiColorProgressBar", "GuiDirectionIndicator", "GuiDistanceControl", "GuiGridConfig", "GuiPhysicalStateControl",
            "GuiShapeConfiguration", "GuiAnimationPanel", "GuiAnimationViewer", "GuiIsoAnimationViewer", "GuiFilterConfiguration",
            "GuiSignalController", "GuiVariantSelector", "CraftingGrid", "GuiBlueprintMoveButton"]
GUI_BASE = {"GuiLayer", "GuiParent", "GuiControl"}; fam = set(GUI_BASE); ch = True
while ch:
    ch = False
    for t in files.values():
        for m in re.finditer(r"\bclass (\w+)(?:<[^>{]*>)?\s+extends\s+(\w+)", t):
            if m.group(2) in fam and m.group(1) not in fam: fam.add(m.group(1)); ch = True
def receiver(s, pos):
    depth = 0; i = pos - 1
    while i >= 0:
        c = s[i]
        if c == ")": depth += 1
        elif c == "(":
            if depth == 0:
                m = re.search(r"([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*)\.(?:add|addLeft|addRight|addCenter)$", s[:i])
                if m: return m.group(1)
            else: depth -= 1
        i -= 1
    return None
ported = []
for cls in ELIGIBLE:
    # find declaring file + constructor
    decl = None
    for f, t in files.items():
        m = re.search(r"\bclass " + cls + r"\b", t)
        if m: decl = f; break
    if not decl: continue
    t = files[decl]
    cm = re.search(r"((?:public|protected|private)\s+)?\b" + cls + r"\(([^)]*)\)(\s*)\{(\s*)(super|this)\(", t)
    if not cm or re.match(r"\s*IGuiParent\b", cm.group(2)): continue
    if re.search(r"\bparent\b", cm.group(2)): pending.append((decl.name, 0, cls + ": ctor already has a `parent` parameter")); continue
    params = cm.group(2).strip(); call_end = cm.end()
    nxt = t[call_end:call_end + 1]
    call = cm.group(5) + "(parent" + ("" if nxt == ")" else ", ")
    t = t[:cm.start()] + (cm.group(1) or "") + cls + "(IGuiParent parent" + (", " + params if params else "") + ")" + cm.group(3) + "{" + cm.group(4) + call + t[call_end:]
    files[decl] = imp(t, "team.creative.creativecore.common.gui.IGuiParent"); changed.add(decl); report["ctor"] += 1; ported.append(cls)
    # call sites everywhere
    for f, t in list(files.items()):
        lines = t.split("\n"); dirty = False
        in_fam = bool(re.search(r"\bclass (\w+)(?:<[^>{]*>)?\s+extends\s+(\w+)", t)) and any(
            mm.group(1) in fam for mm in re.finditer(r"\bclass (\w+)(?:<[^>{]*>)?\s+extends\s+\w+", t))
        for i, l in enumerate(lines):
            for m in list(re.finditer(r"\bnew " + cls + r"\(", l))[::-1]:
                if f == decl and "class" in l: continue
                par = receiver(l, m.start())
                if par is None:
                    ctx = l[:m.start()]
                    is_field = bool(re.match(r"\s*(private|public|protected|static|final)\b", ctx))      # fields carry modifiers, locals do not
                    par = "this" if in_fam and not is_field and "static" not in ctx else None
                if par is None: pending.append((f.name, i + 1, l.strip()[:100])); continue
                rest = l[m.end():]
                l = l[:m.end()] + par + ("" if rest.lstrip().startswith(")") else ", ") + rest; lines[i] = l; dirty = True; report["site"] += 1
        if dirty: files[f] = "\n".join(lines); changed.add(f)
for f in changed: f.write_text(files[f], encoding="utf-8")
print("changed files:", len(changed), dict(report)); print("ported constructors:", ", ".join(ported))
for p in pending: print("  pending:", p[0], p[1], p[2])
