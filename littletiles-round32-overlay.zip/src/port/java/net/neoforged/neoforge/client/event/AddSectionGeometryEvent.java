package net.neoforged.neoforge.client.event;

import net.neoforged.bus.api.Event;

public class AddSectionGeometryEvent extends Event {
    @FunctionalInterface
    public interface AdditionalSectionRenderer {}
}
