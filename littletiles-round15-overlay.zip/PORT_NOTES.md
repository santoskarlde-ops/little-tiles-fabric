
## Round 15 (uncompiled; verified against mc-api.txt / mc-find.txt)
- `RenderType` import -> `net.minecraft.client.renderer.rendertype.RenderType` (mc-find). `PoseStack` unchanged (`com.mojang.blaze3d.vertex`). Still unlocated: MultiBufferSource, Tesselator, BufferUploader, VertexBuffer, GlStateManager (need mc-find2).
- `Item.canAttackBlock` -> `Item.canDestroyBlock(ItemStack, BlockState, Level, BlockPos, LivingEntity)` (8 items). Semantics assumed identical (returns false = creative cannot break): VERIFY in-game.
- `Item.appendHoverText` now `(ItemStack, TooltipContext, TooltipDisplay, Consumer<Component>, TooltipFlag)`; old bodies kept as `appendLegacyTooltip(... List<Component> ...)` bridged via a temp list (Phase 3 may inline).
- `LittleAnimationLevel`: Player->Entity in playSound/playSeededSound/levelEvent; addParticle gained a second boolean; getRecipeManager->recipeAccess(); getMinBuildHeight->getMinY(); added clockManager/environmentAttributes/Respawn data delegating to parentLevel. REMOVED (no longer on Level): setMapData, getFreeMapId (ServerLevel-only), getShade, potionBrewing, DayTime* (replaced by clockManager). Callers of getShade on animation levels need a Phase 4 replacement. More abstract Level methods may still be missing: next log will say.
- `LittlePacketTypes` line ~459: last bare buffer wrapped in `LittleNetBuf.of`.
- Tool: `tools/round15_port.py` (idempotent).
