package net.neoforged.neoforge.common.util;

public enum TriState {
    TRUE, FALSE, DEFAULT;

    public boolean isTrue() { return this == TRUE; }
    public boolean isFalse() { return this == FALSE; }
}
