package team.creative.littletiles.client.render.item;

import java.util.Collections;
import java.util.List;

import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.world.item.ItemStack;
import team.creative.creativecore.client.render.box.RenderBox;
import team.creative.creativecore.client.render.model.box.ItemModelBox;
import team.creative.littletiles.api.common.tool.ILittlePlacer;
import team.creative.littletiles.client.LittleTilesClient;

public class LittleModelItemTiles extends ItemModelBox {
    
    public LittleModelItemTiles() {}
    
    @Override
    public List<? extends RenderBox> getBoxes(ItemStack stack, boolean translucent) {
        ILittlePlacer tool = (ILittlePlacer) stack.getItem();
        if (tool.hasTiles(stack) && tool.shouldRenderInHand(stack))
            return tool.getTiles(stack).getRenderingBoxes(translucent);
        return Collections.EMPTY_LIST;
    }
    
    @Override
    public boolean checkTranslucentLayer(ItemStack stack) {
        ILittlePlacer tool = (ILittlePlacer) stack.getItem();
        if (tool.hasTiles(stack))
            return tool.getTiles(stack).hasTranslucentBlocksInGui();
        return false;
    }
    
    @Override
    public boolean hasTranslucentLayer(ItemStack stack) {
        return LittleTilesClient.ITEM_RENDER_CACHE.hasTranslucent(stack);
    }
    
    @Override
    public void saveCachedModel(boolean translucent, List<BakedQuad> cachedQuads, ItemStack stack, boolean threaded) {}
    
    @Override
    public List<BakedQuad> getCachedModel(boolean translucent, ItemStack stack, boolean threaded) {
        return LittleTilesClient.ITEM_RENDER_CACHE.requestCache(stack, translucent);
    }
    
}
