package team.creative.littletiles.client.render.cache.pipeline;

import java.util.List;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.renderpearl.api.vertex.VertexFormat;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap.Entry;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.neoforged.neoforge.client.model.lighting.QuadLighter;
import team.creative.creativecore.client.render.model.CreativeQuadLighter;
import team.creative.creativecore.common.util.math.base.Facing;
import team.creative.creativecore.common.util.type.list.SingletonList;
import team.creative.creativecore.common.util.type.list.Tuple;
import team.creative.creativecore.common.util.type.map.ChunkLayerMap;
import team.creative.creativecore.common.util.type.map.ChunkLayerMapList;
import team.creative.creativecore.mixin.ForgeModelBlockRendererAccessor;
import team.creative.littletiles.api.client.IFakeRenderingBlock;
import team.creative.littletiles.client.mod.iris.IrisManager;
import team.creative.littletiles.client.render.cache.buffer.BufferCache;
import team.creative.littletiles.client.render.cache.buffer.BufferHolder;
import team.creative.littletiles.client.render.cache.build.RenderingBlockContext;
import team.creative.littletiles.client.render.tile.LittleRenderBox;
import team.creative.littletiles.common.level.little.LittleSubLevel;
import team.creative.littletiles.mixin.client.render.BufferBuilderAccessor;

@Environment(EnvType.CLIENT)
public class LittleRenderPipelineForge extends LittleRenderPipeline {
    
    private final ChunkLayerMap<ByteBufferBuilder> byteBuilder = new ChunkLayerMap<>();
    private final ChunkLayerMap<IntArrayList> indexes = new ChunkLayerMap<>(layer -> new IntArrayList());
    private final MutableBlockPos modelOffset = new MutableBlockPos();
    
    private ByteBufferBuilder getOrCreate(RenderType layer) {
        ByteBufferBuilder buffer = byteBuilder.get(layer);
        if (buffer == null)
            byteBuilder.put(layer, buffer = new ByteBufferBuilder(layer.bufferSize()));
        return buffer;
    }
    
    private void clearIndexes() {
        for (IntArrayList list : indexes)
            list.clear();
    }
    
    @Override
    public void buildCache(PoseStack pose, ChunkLayerMap<BufferCache> buffers, RenderingBlockContext data, VertexFormat format, SingletonList<BakedQuad> bakedQuadWrapper) {
        Level renderLevel = data.be.getLevel();
        while (renderLevel instanceof LittleSubLevel sub && !sub.shouldUseLightingForRenderig())
            renderLevel = sub.getParent();
        
        BlockPos pos = data.be.getBlockPos();
        
        ForgeModelBlockRendererAccessor renderer = (ForgeModelBlockRendererAccessor) MC.getBlockRenderer().getModelRenderer();
        
        QuadLighter smoothLighter = null;
        QuadLighter flatLighter = null;
        
        int overlay = OverlayTexture.NO_OVERLAY;
        
        data.prepareModelOffset(modelOffset, pos);
        pose.translate(modelOffset.getX(), modelOffset.getY(), modelOffset.getZ());
        
        ChunkLayerMap<BufferBuilder> builders = new ChunkLayerMap<>();
        
        for (Entry<ChunkLayerMapList<LittleRenderBox>> entry : data.be.render.cachedBoxes().int2ObjectEntrySet()) {
            ChunkLayerMapList<LittleRenderBox> structureMap = entry.getValue();
            if (structureMap == null || structureMap.isEmpty())
                continue;
            
            for (Tuple<RenderType, List<LittleRenderBox>> tuple : structureMap.tuples()) {
                var cubes = tuple.value;
                if (cubes.isEmpty())
                    continue;
                
                BufferBuilder builder = builders.get(tuple.key);
                if (builder == null)
                    builders.put(tuple.key, builder = new BufferBuilder(getOrCreate(tuple.key), VertexFormat.Mode.QUADS, DefaultVertexFormat.BLOCK));
                
                for (LittleRenderBox cube : cubes) {
                    BlockState state = cube.state;
                    
                    QuadLighter lighter;
                    if (Minecraft.useAmbientOcclusion() && state.getLightEmission(data.be.getLevel(), pos) == 0) {
                        if (smoothLighter == null) {
                            smoothLighter = renderer.getSmoothLighter().get();
                            smoothLighter.setup(renderLevel, pos, data.state);
                        }
                        lighter = smoothLighter;
                    } else {
                        if (flatLighter == null) {
                            flatLighter = renderer.getFlatLighter().get();
                            flatLighter.setup(renderLevel, pos, data.state);
                        }
                        lighter = flatLighter;
                    }
                    
                    ((CreativeQuadLighter) lighter).setState(state);
                    ((CreativeQuadLighter) lighter).setCustomTint(cube.color);
                    
                    if (IrisManager.isShaders()) {
                        if (state.getBlock() instanceof IFakeRenderingBlock fake)
                            state = fake.getFakeState(state);
                        // Iris computes at_midBlock from the submitted vertex positions.
                        // Use their local origin; Sable's large storage positions lose
                        // sub-block precision when Iris converts them to floats.
                        IrisManager.beginBlock(builder, state, modelOffset);
                    }
                    
                    for (int h = 0; h < Facing.VALUES.length; h++) {
                        Facing facing = Facing.VALUES[h];
                        Object quadObject = cube.getQuad(facing);
                        List<BakedQuad> quads = null;
                        if (quadObject instanceof List q)
                            quads = q;
                        else if (quadObject instanceof BakedQuad quad) {
                            bakedQuadWrapper.setElement(quad);
                            quads = bakedQuadWrapper;
                        }
                        if (quads != null && !quads.isEmpty())
                            if (quads instanceof SingletonList<BakedQuad> single)
                                lighter.process(builder, pose.last(), single.get(0), overlay);
                            else
                                for (BakedQuad quad : quads)
                                    lighter.process(builder, pose.last(), quad, overlay);
                    }
                    
                    IrisManager.resetBlockContext(builder);
                    
                    bakedQuadWrapper.setElement(null);
                    
                    cube.deleteQuadCache();
                }
                
                var indexList = indexes.get(tuple.key);
                indexList.add(entry.getIntKey());
                indexList.add(((BufferBuilderAccessor) builder).getVertices() * format.getVertexSize());
            }
        }
        
        for (RenderType layer : RenderType.CHUNK_BUFFER_LAYERS) {
            var builder = builders.get(layer);
            if (builder == null)
                continue;
            var mesh = builder.build();
            if (mesh != null)
                buffers.put(layer, new BufferHolder(mesh, indexes.get(layer).toIntArray()));
        }
        
        clearIndexes();
        
        if (smoothLighter != null) {
            ((CreativeQuadLighter) smoothLighter).setCustomTint(-1);
            smoothLighter.reset();
        }
        if (flatLighter != null) {
            ((CreativeQuadLighter) flatLighter).setCustomTint(-1);
            flatLighter.reset();
        }
    }
    
    @Override
    public void reload() {}
    
    @Override
    public void release() {}
    
}
