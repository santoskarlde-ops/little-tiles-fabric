package team.creative.littletiles.client.mod.sodium.pipeline;

import net.caffeinemc.mods.sodium.client.model.light.data.HashLightDataCache;
import net.minecraft.client.renderer.block.BlockAndTintGetter;

public class LittleLightDataAccess extends HashLightDataCache {
    
    public LittleLightDataAccess() {
        super(null);
    }
    
    public void prepare(BlockAndTintGetter level) {
        this.level = level;
        clearCache();
    }
    
}
