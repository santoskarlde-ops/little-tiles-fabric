# LittleTiles -> Fabric 26.3 port notes

Original mod: LittleTiles by CreativeMD and N247S, LGPL-3.0 (see LICENSE).
Source baseline: upstream `1.21` branch (NeoForge), v1.6.0-pre237.
CreativeCore: upstream `26.x` branch, vendored as submodule `CreativeCore/`.

## Status
- Phase 1: DONE. Dev client launches; LittleTiles and CreativeCore show in Mods. Verified: Loom 1.17.21, Gradle 9.6.0, JDK 25, Loader 0.19.5, Fabric API 0.165.0+26.3, ModMenu 21.0.0.
- Phase 2: CreativeCore gap audit done (PHASE2_AUDIT.md). LittleTiles source staged in src/port/java (OFF by default; `-PportSource=true` enables it; port-excludes.txt keeps mixins and optional-mod code out for now). Applied: CreativeCore package relocations, ResourceLocation -> Identifier (observed in CreativeCore's own 26.x port). BlockFilter and IOriginPose copied into common/compat/creativecore.
- Not yet written: BlockEntityCreative (Fabric), KeyConfig (Fabric), GuiRenderHelper/GuiButtonHoldSlim replacements, anything for the NeoForge events/capabilities. Reason: 26.3 changed block entity save/load (CreativeCore's NeoForge BlockEntityCreative now uses ValueInput), so these need the real 26.3 signatures first.

## Assumptions that held in Phase 1 (kept for reference)
- Loom `1.17-SNAPSHOT`, Gradle 9.6.0, Loader 0.19.5, Fabric API `0.165.0+26.3`.
- `project(':CreativeCore')` built via its `build.fabric.gradle` composes cleanly with this root build.
- CreativeCore's Fabric build script reads `modmenu_version`; value here is a guess.
- `compatibilityLevel` JAVA_21 copied from CreativeCore's mixin config.

## Unported / dropped
Pending decisions are listed in PHASE2_AUDIT.md (KeyConfig modifiers; rendering classes deferred to Phase 4).
