package net.neoforged.neoforge.client.settings;

public enum KeyModifier {
    NONE;
    public boolean matches(KeyModifier other) { return this == other; }
}
