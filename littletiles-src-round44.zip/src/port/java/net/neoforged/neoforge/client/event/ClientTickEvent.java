package net.neoforged.neoforge.client.event;

import net.neoforged.bus.api.Event;

public class ClientTickEvent extends Event {
    public static class Post extends ClientTickEvent {}
    public static class Pre extends ClientTickEvent {}
}
