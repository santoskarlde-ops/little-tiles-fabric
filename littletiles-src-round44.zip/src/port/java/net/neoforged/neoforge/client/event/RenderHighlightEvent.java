package net.neoforged.neoforge.client.event;

import net.neoforged.bus.api.Event;

public class RenderHighlightEvent extends Event {
    public <T> T getTarget() { return null; }
    public <T> T getPoseStack() { return null; }
}
