package net.neoforged.neoforge.client.event;

import net.neoforged.bus.api.Event;

public class RegisterClientCommandsEvent extends Event {
    public <T> T getDispatcher() { return null; }
}
