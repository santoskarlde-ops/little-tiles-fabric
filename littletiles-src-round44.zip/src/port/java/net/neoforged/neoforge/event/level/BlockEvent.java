package net.neoforged.neoforge.event.level;
import net.neoforged.bus.api.Event;
public class BlockEvent extends Event { public static class BreakEvent extends BlockEvent {} }
