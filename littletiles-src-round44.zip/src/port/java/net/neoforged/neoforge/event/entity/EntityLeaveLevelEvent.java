package net.neoforged.neoforge.event.entity;
import net.neoforged.bus.api.Event;
public class EntityLeaveLevelEvent extends Event {}
