package net.neoforged.neoforge.event.entity;
import net.neoforged.bus.api.Event;
public class EntityJoinLevelEvent extends Event {}
