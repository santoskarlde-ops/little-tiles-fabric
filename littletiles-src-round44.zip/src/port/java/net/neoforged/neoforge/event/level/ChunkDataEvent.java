package net.neoforged.neoforge.event.level;
import net.neoforged.bus.api.Event;
public class ChunkDataEvent extends Event { public static class Load extends ChunkDataEvent {} public static class Save extends ChunkDataEvent {} }
