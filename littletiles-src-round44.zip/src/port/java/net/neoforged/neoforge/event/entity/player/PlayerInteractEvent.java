package net.neoforged.neoforge.event.entity.player;

import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.common.util.TriState;

public class PlayerInteractEvent extends Event {
    public TriState getUseBlock() { return TriState.DEFAULT; }
    public TriState getUseItem() { return TriState.DEFAULT; }
    public void setUseBlock(TriState value) {}
    public void setUseItem(TriState value) {}
    public static class EntityInteract extends PlayerInteractEvent {}
    public static class EntityInteractSpecific extends PlayerInteractEvent {}
    public static class LeftClickEmpty extends PlayerInteractEvent {}
    public static class RightClickBlock extends PlayerInteractEvent {}
    public static class RightClickEmpty extends PlayerInteractEvent {}
    public static class RightClickItem extends PlayerInteractEvent {}
    public static class LeftClickBlock extends PlayerInteractEvent {
        public enum Action { START, ABORT, STOP, START_DESTROY_BLOCK, ABORT_DESTROY_BLOCK, STOP_DESTROY_BLOCK }
        public Action getAction() { return Action.START; }
    }
}
