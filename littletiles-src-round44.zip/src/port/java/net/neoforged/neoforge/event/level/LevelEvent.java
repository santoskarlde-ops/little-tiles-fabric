package net.neoforged.neoforge.event.level;
import net.neoforged.bus.api.Event;
public class LevelEvent extends Event { public static class Load extends LevelEvent {} public static class Unload extends LevelEvent {} }
