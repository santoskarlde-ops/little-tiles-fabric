package team.creative.creativecore.common.util.type.map;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

import net.minecraft.client.renderer.rendertype.RenderType;
import team.creative.creativecore.common.util.type.itr.ComputeNextIterator;
import team.creative.creativecore.common.util.type.list.Tuple;

/**
 * Render-layer map whose values are lists, matching the small CreativeCore
 * API used by LittleTiles' box collection and upload paths.
 */
public class ChunkLayerMapList<T> {

    private final List<T>[] content;

    public ChunkLayerMapList() {
        content = (List<T>[]) new List<?>[ChunkLayerMap.LAYERS_COUNT];
    }

    private int index(RenderType layer) {
        for (int i = 0; i < ChunkLayerMap.LAYERS_COUNT; i++)
            if (ChunkLayerMap.layer(i) == layer || ChunkLayerMap.layer(i).equals(layer))
                return i;
        throw new IllegalArgumentException("Unknown chunk render layer: " + layer);
    }

    public List<T> get(RenderType layer) {
        return content[index(layer)];
    }

    public List<T> getOrCreate(RenderType layer) {
        int index = index(layer);
        if (content[index] == null)
            content[index] = new ArrayList<>();
        return content[index];
    }

    public void add(RenderType layer, T value) {
        getOrCreate(layer).add(value);
    }

    public void consumeEachLayer(BiConsumer<RenderType, List<T>> consumer) {
        for (int i = 0; i < ChunkLayerMap.LAYERS_COUNT; i++)
            consumer.accept(ChunkLayerMap.layer(i), getOrCreate(ChunkLayerMap.layer(i)));
    }

    public Iterable<Tuple<RenderType, List<T>>> tuples() {
        return () -> new ComputeNextIterator<>() {
            private int index;
            private final Tuple<RenderType, List<T>> tuple = new Tuple<>(null, null);

            @Override
            protected Tuple<RenderType, List<T>> computeNext() {
                while (index < content.length && (content[index] == null || content[index].isEmpty()))
                    index++;
                if (index >= content.length)
                    return end();
                tuple.key = ChunkLayerMap.layer(index);
                tuple.value = content[index++];
                return tuple;
            }
        };
    }
}