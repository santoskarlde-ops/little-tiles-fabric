package net.neoforged.neoforge.event.level;
import net.neoforged.bus.api.Event;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
public class BlockEvent extends Event {
    public static class BreakEvent extends BlockEvent {
        public BreakEvent() {}
        public BreakEvent(Level level, BlockPos pos, BlockState state, Player player) {}
    }
}
