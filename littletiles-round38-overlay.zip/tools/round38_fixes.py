#!/usr/bin/env python3
"""Round 38: small, signature-verified fixes driven by the javac log (idempotent). Run from the project root:
    python3 tools/round38_fixes.py build.log src/port/java
1. GuiPlayerInventoryGrid: javac says the 26.x constructor is (IGuiParent) only, so `new GuiPlayerInventoryGrid(parent, player)`
   becomes `new GuiPlayerInventoryGrid(parent)`. (Where the player now comes from is a CreativeCore question: check at runtime.)
2. GuiParent.controls is private. For bare `controls` inside GuiParent subclasses, only calls with an identical public equivalent
   on GuiParent are rewritten: controls.size() -> size(), controls.get(i) -> get(i), controls.remove(x) -> remove(x).
   NOT rewritten (listed instead): clear() and iteration. GuiParent.clear() also clears hover controls and the old field list
   did not, so those need a human decision."""
import re, sys, pathlib, collections
log = open(sys.argv[1], encoding="utf-8", errors="replace").read().split("\n"); root = pathlib.Path(sys.argv[2])
rx = re.compile(r"^.*?src/port/java/(.*\.java):(\d+): error: (.*)$")
grid, ctrl = {}, {}
for i, l in enumerate(log):
    m = rx.match(l)
    if not m: continue
    f, n, msg = m.group(1), int(m.group(2)), m.group(3)
    if "constructor GuiPlayerInventoryGrid" in msg:
        req = next((x.strip() for x in log[i + 1:i + 6] if x.strip().startswith("required:")), "")
        if req == "required: IGuiParent": grid[(f, n)] = log[i + 1]
    elif msg.startswith("controls has private access in GuiParent"): ctrl[(f, n)] = log[i + 1]
done = collections.Counter(); manual = []
GRID = re.compile(r"new GuiPlayerInventoryGrid\(\s*([^,()]+?)\s*,\s*[^()]*(?:\([^()]*\))?[^()]*\)")
CALL = re.compile(r"(?<![\w.])controls\.(size|get|remove)\(")
edits = collections.defaultdict(dict)
for (f, n), src in grid.items(): edits[f][n] = ("grid", src)
for (f, n), src in ctrl.items(): edits[f].setdefault(n, ("ctrl", src))
for f, lines in edits.items():
    p = root / f
    if not p.exists(): manual.append((f, 0, "file missing")); continue
    text = p.read_text(encoding="utf-8").split("\n"); dirty = False
    for n, (kind, srcline) in lines.items():
        s = text[n - 1] if n <= len(text) else ""
        if s.strip() != srcline.strip():
            if "GuiPlayerInventoryGrid(" in s and not GRID.search(s) or "controls." not in s and kind == "ctrl": continue   # already ported
            manual.append((f, n, "line differs from log")); continue
        if kind == "grid":
            new, k = GRID.subn(r"new GuiPlayerInventoryGrid(\1)", s)
            if k: text[n - 1] = new; done["GuiPlayerInventoryGrid"] += k; dirty = True
            else: manual.append((f, n, s.strip()[:100]))
        else:
            new, k = CALL.subn(lambda m: m.group(1) + "(", s)
            if k: text[n - 1] = new; done["controls." ] += k; dirty = True
            else: manual.append((f, n, s.strip()[:100]))
    if dirty: p.write_text("\n".join(text), encoding="utf-8")
print("ported:", dict(done))
print("left manual:", len(manual))
for m in manual: print("  ", m[0].split("/")[-1], m[1], "|", m[2])
