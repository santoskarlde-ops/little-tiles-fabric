package team.creative.littletiles.common.mod.sable;

import org.joml.Matrix4f;
import org.joml.Matrix4fStack;
import org.joml.Quaternionf;
import org.joml.Vector3d;

import com.mojang.blaze3d.vertex.PoseStack;

import dev.ryanhcode.sable.companion.ClientSubLevelAccess;
import dev.ryanhcode.sable.companion.math.Pose3dc;
import dev.ryanhcode.sable.sublevel.SubLevel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import team.creative.creativecore.common.util.math.box.ABB;
import team.creative.creativecore.common.util.math.box.BoxCorner;
import team.creative.littletiles.common.entity.LittleEntity;
import team.creative.littletiles.common.entity.animation.LittleAnimationEntity;
import team.creative.littletiles.common.level.context.ILittleLevelContext;
import team.creative.littletiles.common.level.little.LittleLevel;

public class SableContext implements ILittleLevelContext {
    
    public static Matrix4f transform(Pose3dc pose, double x, double y, double z, Vec3 camera) {
        Vec3 subCamera = pose.transformPositionInverse(camera);
        Matrix4f matrix = new Matrix4f();
        matrix.translate((float) (pose.position().x() - camera.x), (float) (pose.position().y() - camera.y), (float) (pose.position().z() - camera.z));
        matrix.rotate(new Quaternionf(pose.orientation()));
        matrix.translate((float) (subCamera.x - pose.rotationPoint().x()), (float) (subCamera.y - pose.rotationPoint().y()), (float) (subCamera.z - pose.rotationPoint().z()));
        matrix.scale((float) pose.scale().x(), (float) pose.scale().y(), (float) pose.scale().z());
        matrix.translate((float) (x - subCamera.x), (float) (y - subCamera.y), (float) (z - subCamera.z));
        return matrix;
    }
    
    public static void transformPose(Pose3dc pose, PoseStack stack, double x, double y, double z, Vec3 camera) {
        Vec3 subCamera = pose.transformPositionInverse(camera);
        stack.translate((float) (pose.position().x() - camera.x), (float) (pose.position().y() - camera.y), (float) (pose.position().z() - camera.z));
        stack.mulPose(new Quaternionf(pose.orientation()));
        stack.translate((float) (subCamera.x - pose.rotationPoint().x()), (float) (subCamera.y - pose.rotationPoint().y()), (float) (subCamera.z - pose.rotationPoint().z()));
        stack.scale((float) pose.scale().x(), (float) pose.scale().y(), (float) pose.scale().z());
        stack.translate((float) (x - subCamera.x), (float) (y - subCamera.y), (float) (z - subCamera.z));
    }
    
    public static void transformMatrix(Pose3dc pose, Matrix4fStack matrix, double x, double y, double z, Vec3 camera) {
        Vec3 subCamera = pose.transformPositionInverse(camera);
        matrix.translate((float) (pose.position().x() - camera.x), (float) (pose.position().y() - camera.y), (float) (pose.position().z() - camera.z));
        matrix.rotate(new Quaternionf(pose.orientation()));
        matrix.translate((float) (subCamera.x - pose.rotationPoint().x()), (float) (subCamera.y - pose.rotationPoint().y()), (float) (subCamera.z - pose.rotationPoint().z()));
        matrix.scale((float) pose.scale().x(), (float) pose.scale().y(), (float) pose.scale().z());
        matrix.translate((float) (x - subCamera.x), (float) (y - subCamera.y), (float) (z - subCamera.z));
    }
    
    public final SubLevel level;
    
    public SableContext(SubLevel level) {
        this.level = level;
    }
    
    @Override
    public Matrix4f transform(double x, double y, double z, Vec3 camera, float partialTick) {
        Pose3dc pose = ((ClientSubLevelAccess) level).renderPose(partialTick);
        return transform(pose, x, y, z, camera);
    }
    
    @Override
    @Environment(EnvType.CLIENT)
    @Environment(EnvType.CLIENT)
    public void transformPose(PoseStack stack, double x, double y, double z, Vec3 camera, float partialTick) {
        Pose3dc pose = ((ClientSubLevelAccess) level).renderPose(partialTick);
        transformPose(pose, stack, x, y, z, camera);
    }
    
    @Override
    @Environment(EnvType.CLIENT)
    @Environment(EnvType.CLIENT)
    public void transformMatrix(Matrix4fStack matrix, double x, double y, double z, Vec3 camera, float partialTick) {
        Pose3dc pose = ((ClientSubLevelAccess) level).renderPose(partialTick);
        transformMatrix(pose, matrix, x, y, z, camera);
    }
    
    @Override
    public Matrix4f transformInverse(double x, double y, double z, Vec3 camera, float partialTick) {
        return transform(x, y, z, camera, partialTick).invert();
    }
    
    @Override
    public Vec3 toFakeWorld(Vec3 vec) {
        return level.logicalPose().transformPositionInverse(vec);
    }
    
    @Override
    public Vec3 toFakeWorld(Vec3 vec, float partialTick) {
        return ((ClientSubLevelAccess) level).renderPose(partialTick).transformPositionInverse(vec);
    }
    
    @Override
    public AABB toFakeWorld(AABB box) {
        var pose = level.logicalPose();
        ABB bb = ABB.createEmptyBox();
        Vector3d vec = new Vector3d();
        for (int i = 0; i < BoxCorner.values().length; i++) {
            BoxCorner.values()[i].set(box, vec);
            
            pose.transformPositionInverse(vec);
            
            bb.minX = Math.min(bb.minX, vec.x);
            bb.minY = Math.min(bb.minY, vec.y);
            bb.minZ = Math.min(bb.minZ, vec.z);
            bb.maxX = Math.max(bb.maxX, vec.x);
            bb.maxY = Math.max(bb.maxY, vec.y);
            bb.maxZ = Math.max(bb.maxZ, vec.z);
        }
        
        return bb.toVanilla();
    }
    
    @Override
    public AABB toFakeWorld(AABB box, float partialTick) {
        var pose = ((ClientSubLevelAccess) level).renderPose(partialTick);
        ABB bb = ABB.createEmptyBox();
        Vector3d vec = new Vector3d();
        for (int i = 0; i < BoxCorner.values().length; i++) {
            BoxCorner.values()[i].set(box, vec);
            
            pose.transformPositionInverse(vec);
            
            bb.minX = Math.min(bb.minX, vec.x);
            bb.minY = Math.min(bb.minY, vec.y);
            bb.minZ = Math.min(bb.minZ, vec.z);
            bb.maxX = Math.max(bb.maxX, vec.x);
            bb.maxY = Math.max(bb.maxY, vec.y);
            bb.maxZ = Math.max(bb.maxZ, vec.z);
        }
        
        return bb.toVanilla();
    }
    
    @Override
    public Vec3 toRealWorld(Vec3 vec) {
        return level.logicalPose().transformPosition(vec);
    }
    
    @Override
    public Vec3 toRealWorld(Vec3 vec, float partialTick) {
        return ((ClientSubLevelAccess) level).renderPose(partialTick).transformPosition(vec);
    }
    
    @Override
    public AABB toRealWorld(AABB box) {
        var pose = level.logicalPose();
        ABB bb = ABB.createEmptyBox();
        Vector3d vec = new Vector3d();
        for (int i = 0; i < BoxCorner.values().length; i++) {
            BoxCorner.values()[i].set(box, vec);
            
            pose.transformPosition(vec);
            
            bb.minX = Math.min(bb.minX, vec.x);
            bb.minY = Math.min(bb.minY, vec.y);
            bb.minZ = Math.min(bb.minZ, vec.z);
            bb.maxX = Math.max(bb.maxX, vec.x);
            bb.maxY = Math.max(bb.maxY, vec.y);
            bb.maxZ = Math.max(bb.maxZ, vec.z);
        }
        
        return bb.toVanilla();
    }
    
    @Override
    public AABB toRealWorld(AABB box, float partialTick) {
        var pose = ((ClientSubLevelAccess) level).renderPose(partialTick);
        ABB bb = ABB.createEmptyBox();
        Vector3d vec = new Vector3d();
        for (int i = 0; i < BoxCorner.values().length; i++) {
            BoxCorner.values()[i].set(box, vec);
            
            pose.transformPosition(vec);
            
            bb.minX = Math.min(bb.minX, vec.x);
            bb.minY = Math.min(bb.minY, vec.y);
            bb.minZ = Math.min(bb.minZ, vec.z);
            bb.maxX = Math.max(bb.maxX, vec.x);
            bb.maxY = Math.max(bb.maxY, vec.y);
            bb.maxZ = Math.max(bb.maxZ, vec.z);
        }
        
        return bb.toVanilla();
    }
    
    @Override
    public int hashCode() {
        return level.hashCode();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof SableContext c)
            return c.level == level;
        return false;
    }
    
    @Override
    public boolean is(ILittleLevelContext context) {
        if (context instanceof SableContext s)
            return s.level == level;
        return false;
    }
    
    @Override
    public boolean isChildOf(LevelAccessor level) {
        if (level instanceof LittleLevel l && l.getHolder() instanceof LittleEntity e) {
            e = e.getTopLevelEntity();
            if (e instanceof LittleAnimationEntity a)
                return is(ILittleLevelContext.of(e.level(), a.getCenter().baseOffset));
        }
        return false;
    }
}
