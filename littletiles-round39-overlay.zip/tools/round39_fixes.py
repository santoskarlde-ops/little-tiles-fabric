#!/usr/bin/env python3
"""Round 39: small, evidence-backed fixes driven by the javac log (idempotent). Usage:
    python3 tools/round39_fixes.py build.log src/port/java
Only lines javac flagged are touched. Evidence per fix:
 1. new GuiPlayerInventoryGrid(parent, player) -> (parent): javac: `required: IGuiParent`.
 2. bare controls.size()/get(i)/remove(x) -> size()/get(i)/remove(x): GuiParent.controls is private; GuiParent has public size/get(int)/remove.
 3. align/valign/spacing assignments -> setAlign/setVAlign/setSpacing: public GuiParent methods in the CreativeCore 26.x sources.
 4. ResourceKey.location() -> identifier(): Mojang rename in 1.21.11 (third-party release notes); javac flags location() on ResourceKey.
 5. <x>.getProfiler() on Minecraft/MinecraftServer -> Profiler.get() (+import net.minecraft.util.profiling.Profiler): replacement
    introduced in 1.21.2 and still used by current Mojmap-based code. NOT compiled against 26.3.
Not touched: clear()/iteration over `controls` (GuiParent.clear() also clears hover controls)."""
import re, sys, pathlib, collections
log = open(sys.argv[1], encoding="utf-8", errors="replace").read().split("\n"); root = pathlib.Path(sys.argv[2])
rx = re.compile(r"^.*?src/port/java/(.*\.java):(\d+): error: (.*)$")
todo = collections.defaultdict(dict)       # file -> line -> (kind, original source line)
for i, l in enumerate(log):
    m = rx.match(l)
    if not m: continue
    f, n, msg = m.group(1), int(m.group(2)), m.group(3); src = log[i + 1]
    sym = loc = ""
    for x in log[i + 2:i + 8]:
        x = x.strip()
        if ": error:" in x: break
        if x.startswith("symbol:"): sym = x[7:].strip()
        if x.startswith("location:"): loc = x[9:].strip()
    kind = None
    if "constructor GuiPlayerInventoryGrid" in msg and any(x.strip() == "required: IGuiParent" for x in log[i + 1:i + 6]): kind = "grid"
    elif msg.startswith("controls has private access in GuiParent"): kind = "ctrl"
    elif msg == "cannot find symbol":
        if sym in ("variable align", "variable valign", "variable spacing"): kind = sym.split()[1]
        elif sym == "method location()" and loc.startswith("class ResourceKey"): kind = "loc"
        elif sym == "method getProfiler()" and (loc.startswith("class MinecraftServer") or "of type Minecraft" in loc or loc.startswith("class Minecraft")): kind = "prof"
    if kind: todo[f].setdefault(n, (set(), src))[0].add(kind)
SET = {"align": "setAlign", "valign": "setVAlign", "spacing": "setSpacing"}
GRID = re.compile(r"new GuiPlayerInventoryGrid\(\s*([^,()]+?)\s*,\s*[^()]*(?:\([^()]*\))?[^()]*\)")
CTRL = re.compile(r"(?<![\w.])controls\.(size|get|remove)\(")
LOC = re.compile(r"\.location\(\)")
PROF = re.compile(r"(?<![\w.])(?:[A-Za-z_][\w]*(?:\([^()]*\))?\.)*[A-Za-z_][\w]*(?:\([^()]*\))?\.getProfiler\(\)")
IMPORT = "import net.minecraft.util.profiling.Profiler;"
done = collections.Counter(); manual = []
for f, lines in todo.items():
    p = root / f; text = p.read_text(encoding="utf-8").split("\n"); need_import = False; dirty = False
    for n, (kinds, src) in lines.items():
        s = text[n - 1]
        if s.strip() != src.strip(): continue                       # already edited (or file differs from the log)
        for k in sorted(kinds):
            before = s
            if k == "grid": s = GRID.sub(r"new GuiPlayerInventoryGrid(\1)", s)
            elif k == "ctrl": s = CTRL.sub(lambda m: m.group(1) + "(", s)
            elif k in SET:
                s = re.sub(r"(^\s*|[\w)\]]\.)%s\s*=(?!=)\s*(.+);\s*$" % k, lambda m: m.group(1) + SET[k] + "(" + m.group(2) + ");", s)
            elif k == "loc": s = LOC.sub(".identifier()", s)
            elif k == "prof":
                s = PROF.sub("Profiler.get()", s); need_import = need_import or s != before
            if s != before: done[k] += 1
            else: manual.append((f, n, k, before.strip()[:110]))
        if s != text[n - 1]: text[n - 1] = s; dirty = True
    if need_import and IMPORT not in "\n".join(text):
        i = next((j for j, t in enumerate(text) if t.startswith("import ")), None)
        if i is None: i = next(j for j, t in enumerate(text) if t.startswith("package ")) + 1
        text.insert(i, IMPORT)
    if dirty: p.write_text("\n".join(text), encoding="utf-8")
print("fixed lines:", dict(done)); print("left manual:", len(manual))
for m in manual: print("  ", m[0].split("/")[-1], m[1], m[2], "|", m[3])
