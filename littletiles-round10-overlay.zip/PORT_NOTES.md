# LittleTiles -> Fabric 26.3 port notes

Original mod: LittleTiles by CreativeMD and N247S, LGPL-3.0 (see LICENSE).
Source baseline: upstream `1.21` branch (NeoForge), v1.6.0-pre237.
CreativeCore: upstream `26.x` branch, vendored as submodule `CreativeCore/`.

## Status
- Phase 1: DONE. Dev client launches; LittleTiles and CreativeCore show in Mods. Verified: Loom 1.17.21, Gradle 9.6.0, JDK 25, Loader 0.19.5, Fabric API 0.165.0+26.3, ModMenu 21.0.0.
- Phase 2: CreativeCore gap audit done (PHASE2_AUDIT.md). LittleTiles source staged in src/port/java (OFF by default; `-PportSource=true` enables it; port-excludes.txt keeps mixins and optional-mod code out for now). Applied: CreativeCore package relocations, ResourceLocation -> Identifier (observed in CreativeCore's own 26.x port). BlockFilter and IOriginPose copied into common/compat/creativecore.
- Not yet written: BlockEntityCreative (Fabric), KeyConfig (Fabric), GuiRenderHelper/GuiButtonHoldSlim replacements, anything for the NeoForge events/capabilities. Reason: 26.3 changed block entity save/load (CreativeCore's NeoForge BlockEntityCreative now uses ValueInput), so these need the real 26.3 signatures first.

## Assumptions that held in Phase 1 (kept for reference)
- Loom `1.17-SNAPSHOT`, Gradle 9.6.0, Loader 0.19.5, Fabric API `0.165.0+26.3`.
- `project(':CreativeCore')` built via its `build.fabric.gradle` composes cleanly with this root build.
- CreativeCore's Fabric build script reads `modmenu_version`; value here is a guess.
- `compatibilityLevel` JAVA_21 copied from CreativeCore's mixin config.

## Unported / dropped
Pending decisions are listed in PHASE2_AUDIT.md (KeyConfig modifiers; rendering classes deferred to Phase 4).

## Compile round 1 (4,742 javac errors, mostly cascades)
Bulk fixes applied: OnlyIn -> @Environment, isClientSide(), net.minecraft.util.Util, jsr305 dependency, NBT Optional getters (error-driven, tools/fix_nbt_optionals.py).
Biggest remaining blocks, in order of size:
1. GUI: CreativeCore 26.x controls now take the parent first (`new GuiButton(this, "name", ...)`) and split client code into dist classes. Affects ~95 files in common/gui. Needs manual port, not a codemod.
2. Rendering: RenderType, ChunkLayerMap, BakedQuad, VertexFormat, BufferUploader, Tesselator, PoseStack-era GL calls (Phase 4).
3. Events/registries: NeoForge.EVENT_BUS, DeferredHolder/DeferredRegister, CommonHooks, IngredientType.
4. BlockEntity: BETiles overrides old load/save/update signatures (26.3 uses ValueInput/ValueOutput).
Known gaps in the codemods: getList(k, type) -> getListOrEmpty(k) drops the element-type filter; 53 flagged lines were not auto-fixable.

## Compile round 2
- Bare `isClientSide` field reads inside Level subclasses (LittleAnimationLevel x7, FakeClientLevel x1) -> `isClientSide()`. Round 1's codemod only covered `x.isClientSide`.
- `javax.annotation.Nullable` via jsr305 is a compile shortcut. Minecraft 26.x itself uses `org.jspecify.annotations.Nullable`; whether CreativeCore uses jsr305 is unverified. Revisit (mechanical swap) before release.
- `getList(k, type)` -> `getListOrEmpty(k)` drops the element-type filter; re-add explicit type checks where save compatibility matters (Phase 3).
- Next: rebuild with round 1 + round 2 applied and triage the new log; then GUI port (CreativeCore 26.x controls take the parent first; ~95 files in common/gui).

## Compile round 3 (build_1.log: 3,549 unique errors in 316 files, down from 4,487 / 407)
- Reran tools/fix_nbt_optionals.py on the new log (68 flagged lines, 74 rewrites, 16 files); these were hidden behind earlier errors.
- Blocked on real 26.3 signatures: BlockEntityCreative (BETiles superclass; 58 "BlockEntity cannot be converted to BETiles" and many "does not override" cascade from it), then GUI (parent-first constructors), then rendering (RenderType, ChunkLayerMap, BakedQuad, VertexFormat: Phase 4).

## Compile round 4-5: GUI constructors (3,483 -> 3,081 unique errors after round 4; build_319a43.log)
- tools/gui_parent_first.py: parent-first constructors for 37 GUI classes, 498 call sites total (446 in round 4 + 52 in round 5). Signatures are taken from javac output, e.g. GuiButton(IGuiParent,String,Consumer<Integer>), GuiLabel(IGuiParent,String), GuiParent(IGuiParent,String) / (IGuiParent,GuiFlow), GuiListBoxBase(IGuiParent,String,boolean,List). Constructor errors for GuiButton, GuiLabel and GuiCheckBox are now 0 in the log.
- UNVERIFIED (compiler cannot check): parent argument = receiver of the enclosing `x.add*(...)`, else `this`; and whether 26.x constructors also register the control with the parent (would double-add). Verify against CreativeCore GuiControl/GuiParent before Phase 5.
- `this` is not an IGuiParent at 10 sites (anonymous classes / non-GUI classes), the right container must be chosen by hand: GuiDialogSignalVirtualInput:106, GuiParticle:61,65,72,77,101,105,112,117, SignalMode:316.
- Still manual: GuiLayer (26.x ctors start with a boolean of unknown meaning, 22 errors left), `super(...)`/`this(...)` in GuiParent subclasses (44), GUI subclass constructors that need a parent parameter (OverlayRenderer, GuiParticleControl, GuiTimelinePanel, LittleStructureGuiControl, GuiSignalInputConfig).

## Round 6 (build_a6bf46.log: 3,042 unique errors, 307 files)
- Round 5 left the log almost unchanged (3,081 -> 3,042); remaining errors need CreativeCore 26.x sources (BlockEntityCreative, GuiControl/GuiParent/GuiLayer, KeyConfig) or hand porting.
- NeoForge replacement plan with verification status: PORT_EVENTS.md.

## Round 7: verified against CreativeCore 26.x sources (cc-sources.zip)
- GuiControl(IGuiParent parent, String name) only stores the parent (used for isClient()/dist lookup). It does NOT register the control; GuiParent.add(control) adds it and calls setParent(control, this). So the round 4/5 parent argument (enclosing add() receiver, else `this`) is correct and there is no double-add risk. That assumption is now verified.
- GuiLayer(boolean client, String name[, int width, int height]): the boolean picks the CLIENT or SERVER layer destination. All 21 `extends GuiLayer` classes need a `client` value; where it comes from depends on GuiCreator (source needed, see below).
- GuiControl.setVisible/setEnabled forward to `dist` (client-only dist handler). The old public fields `visible`, `enabled`, `rect`, GuiCheckBox.value no longer exist on the control; the replacement accessors live in the dist handlers / GuiCheckBox (sources needed).
- BlockEntityCreative: Fabric version added at CreativeCore/src/fabric/java/team/creative/creativecore/common/be/. Requires BETiles to drop `handleUpdate` and port loadAdditional/saveAdditional from (CompoundTag, Provider) to the 26.x ValueInput/ValueOutput signatures (vanilla now uses them; confirmed by the Entity errors in the log). Save-format preservation depends on the ValueInput/ValueOutput API: NOT done yet.
- TriFunction: net.minecraft.data.models.blockstates.PropertyDispatch.TriFunction no longer exists; replaced with team.creative.littletiles.common.util.function.TriFunction in LittleTileGuiCreator and LittleStructureGuiCreator.
- KeyConfig (src/forge) depends on NeoForge KeyModifier/InputEvent; Fabric version still to write.

## Round 8 (build_514cb7.log: 2,876 unique errors / 291 files, down from 3,042 / 307)
- BETiles cast errors 58 -> 0 after the Fabric BlockEntityCreative. CreativeCore:compileJava passes.
- tools/gui_members.py (caret-driven, verified against GuiParent/GuiControl/GuiCheckBox sources): GuiParent.flow = X -> setFlow(X) (48), visible/enabled assignments -> setVisible/setEnabled (5), GuiCheckBox.value reads -> get() (38), value writes -> GuiCompat.setSilent (3; set() notifies listeners, the old field write did not). Note get() returns false on the server (no dist handler); check any server-side logic that read a checkbox value.
- Left: `rect` (113 hits; needs the client dist classes), 6 reads of GuiCheckBox.enabled (no getter in the sources seen), 2 `flow` and 1 `value` leftovers.
- tools/gui_layer_client.py: GuiLayer(boolean client, ...) is now threaded through 33 GuiLayer classes (35 constructors) and 27 instantiation sites (player.level().isClientSide() inside creator lambdas, isClient() inside layers, true for OverlayGuiLayer, false in the server branch of STRUCTURE_SIGNAL).
- Pending: the 6 GuiSyncHolder.GLOBAL.layer("...", (x, y) -> new GuiDialog...()) sites in LittleTilesGuiRegistry (lines 35-42): the meaning of (x, y) is unknown without GuiSyncHolder.java / GuiSyncGlobalLayer.java.
- Still open: BETiles ValueInput/ValueOutput port (148 "does not override" there), KeyConfig, NeoForge events/registries, rendering (Phase 4).

## Round 9 (build_ecdcc6.log: 2,771 unique errors / 281 files, down from 2,876 / 291)
- Round 8 codemods landed: the flow/value/enabled/visible errors are gone from the log.
- GuiSyncHolder.GLOBAL.layer(id, TriFunction<Boolean, HolderLookup.Provider, CompoundTag, T>) is verified from source: the 6 `(x, y) -> new GuiDialog...()` sites in LittleTilesGuiRegistry became `(client, provider, tag) -> new GuiDialog...(client)`.
- rect/enabled/visible now live in GuiClientControl (the control's client dist handler, `control.dist()` cast). Added client/gui/GuiClientCompat (rect/isEnabled/isVisible, client code only). tools/gui_members.py ported 54 `rect` reads, 3 `enabled` reads, 2 more `value` reads and 1 more `flow` write. Its log parser no longer reads the next error's symbol/caret (earlier runs had 6 false "left manual" hits).
- NEW STRUCTURAL FINDING (explains most of the 306 "does not override" errors): in CreativeCore 26.x a control is split in two. The common class (e.g. GuiLabel extends GuiControl) keeps state and a nested `XDist` interface; rendering, flow and input (renderContent(GuiGraphicsExtractor, ...), flowX/flowY, mouseMoved, looseFocus, ...) moved to a client class (GuiClientLabel<T extends GuiLabel> extends GuiClientControl<T> implements GuiLabelDist). LittleTiles' own controls (about 60) that override those methods must be split the same way. How a control class is mapped to its client class (the createDist registry) is not in the sources seen yet.
- Also: the graphics type is GuiGraphicsExtractor in 26.x (the log's 24 GuiGraphics errors).
- LittleParticle: `lifetime` field missing (particle API change), not GUI related.

## Round 10 (build_1.log triage)
- BUG FIXED (mine): .gitignore had `build/`, which silently excluded src/port/java/.../client/render/cache/build/ (4 files: RenderingBlockContext, RenderingBlockQueue, RenderingLevelHandler, RenderingThread) from every overlay zip since the first. 23 files import it, so it caused a large share of the unresolved-symbol errors. Now anchored as `/build/`; the 4 files are in this overlay.
- Fixed: 26 "Environment is not a repeatable annotation" errors (upstream already had @Environment beside @OnlyIn; codemod now dedupes).
- build_1.log: 5,426 unique errors / 552 files, all source lines match the round-9 tree. Higher than the round-8 figure (2,771 / 281), which is consistent with the missing folder, but this is not yet confirmed: only the next log can show it.
